Zeus includes adaptations of the Annnimate Starter Pack supplied by the user, created by Good Fella (Julian and Adrian), https://annnimate.com.

Affected components: TextReveal, AnimatedAccordion, DualScramble, MultiLevelDrawerMenu, ImageFlyIn, ScaleSlider, CurtainSlider, FeatureDialog, AsciiOverlay and AnimatedPricing. Original author notices and the supplied usage statement are retained in the source repository at docs/references/annnimate-starter-pack-README.md. The pack describes its components as available to paste into any project, without attribution or expiration.

MorphingTooltip is an independent Zeus reconstruction from a public rendered preview. GSAP, @gsap/react, Three.js and other dependencies retain their respective licenses.
